import components.queue.Queue;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.statement.Statement;
import components.statement.Statement1;
import components.utilities.Reporter;
import components.utilities.Tokenizer;

/**
 * Layered implementation of secondary methods {@code parse} and
 * {@code parseBlock} for {@code Statement}.
 *
 * @author Put your name here
 *
 */
public final class Statement1Parse1 extends Statement1 {

    /*
     * Private members --------------------------------------------------------
     */

    /**
     * Converts {@code c} into the corresponding {@code Condition}.
     *
     * @param c
     *            the condition to convert
     * @return the {@code Condition} corresponding to {@code c}
     * @requires [c is a condition string]
     * @ensures parseCondition = [Condition corresponding to c]
     */
    private static Condition parseCondition(String c) {
        assert c != null : "Violation of: c is not null";
        assert Tokenizer
                .isCondition(c) : "Violation of: c is a condition string";
        return Condition.valueOf(c.replace('-', '_').toUpperCase());
    }

    /**
     * Parses an IF or IF_ELSE statement from {@code tokens} into {@code s}.
     *
     * @param tokens
     *            the input tokens
     * @param s
     *            the parsed statement
     * @replaces s
     * @updates tokens
     * @requires <pre>
     * [<"IF"> is a prefix of tokens]  and
     *  [<Tokenizer.END_OF_INPUT> is a suffix of tokens]
     * </pre>
     * @ensures <pre>
     * if [an if string is a proper prefix of #tokens] then
     *  s = [IF or IF_ELSE Statement corresponding to if string at start of #tokens]  and
     *  #tokens = [if string at start of #tokens] * tokens
     * else
     *  [reports an appropriate error message to the console and terminates client]
     * </pre>
     */
    private static void parseIf(Queue<String> tokens, Statement s) {
        assert tokens != null : "Violation of: tokens is not null";
        assert s != null : "Violation of: s is not null";
        assert tokens.length() > 0 && tokens.front().equals("IF") : tokens
                .front() + " Violation of: <\"IF\"> is proper prefix of tokens";
        Condition cond;
        String token = "";
        System.out.println("If called");
        Statement bdyIf = s.newInstance();
        Statement bdyElse = s.newInstance();

        //dequeues "if"
        tokens.dequeue();

        //parses condition
        token = tokens.dequeue();
        Reporter.assertElseFatalError(Tokenizer.isCondition(token),
                "Expected condition, but instead found " + token);
        cond = parseCondition(token);

        //dequeues "then"
        token = tokens.dequeue();
        Reporter.assertElseFatalError(token.equals("THEN"),
                "Expected keyword \"THEN\", but instead found " + token);

        //parses if block if not empty
        if (!tokens.front().equals("END")) {
            bdyIf.parseBlock(tokens);
        }
        //if there is an else
        if (tokens.front().equals("ELSE")) {
            System.out.println("Else called");

            //dequeues "else"
            tokens.dequeue();

            //parses else block if not empty
            if (!tokens.front().equals("END")) {
                bdyElse.parseBlock(tokens);
            }
            s.assembleIfElse(cond, bdyIf, bdyElse);
        } else {//if no else
            s.assembleIf(cond, bdyIf);
        }
        //System.out.println(s.toString());
        //parses "end"
        token = tokens.dequeue();
        Reporter.assertElseFatalError(token.equals("END"),
                "Expected keyword \"END\" but instead found " + token);
        token = tokens.dequeue();
        Reporter.assertElseFatalError(token.equals("IF"),
                "Expected \"IF\", but instead found " + token);
    }

    /**
     * Parses a WHILE statement from {@code tokens} into {@code s}.
     *
     * @param tokens
     *            the input tokens
     * @param s
     *            the parsed statement
     * @replaces s
     * @updates tokens
     * @requires <pre>
     * [<"WHILE"> is a prefix of tokens]  and
     *  [<Tokenizer.END_OF_INPUT> is a suffix of tokens]
     * </pre>
     * @ensures <pre>
     * if [a while string is a proper prefix of #tokens] then
     *  s = [WHILE Statement corresponding to while string at start of #tokens]  and
     *  #tokens = [while string at start of #tokens] * tokens
     * else
     *  [reports an appropriate error message to the console and terminates client]
     * </pre>
     */
    private static void parseWhile(Queue<String> tokens, Statement s) {
        assert tokens != null : "Violation of: tokens is not null";
        assert s != null : "Violation of: s is not null";
        assert tokens.length() > 0 && tokens.front().equals("WHILE") : tokens
                .front()
                + " Violation of: <\"WHILE\"> is proper prefix of tokens";
        String token = "";
        Condition cond;
        SimpleWriter out = new SimpleWriter1L();

        Statement bdy = s.newInstance();

        System.out.println("While called");

        //dequeues "while"
        tokens.dequeue();

        //parses condition
        token = tokens.dequeue();
        Reporter.assertElseFatalError(Tokenizer.isCondition(token),
                "Expected condition, but instead found " + token);
        cond = parseCondition(token);

        //dequeues "do"
        token = tokens.dequeue();
        Reporter.assertElseFatalError(token.equals("DO"),
                "Expected keyword \"DO\", but instead found " + token);

        //parses block if its not empty
        if (!tokens.front().equals("END")) {
            bdy.parseBlock(tokens);
        }

        s.assembleWhile(cond, bdy);
        s.prettyPrint(out, 0);
        //parses "end"
        token = tokens.dequeue();
        Reporter.assertElseFatalError(token.equals("END"),
                "Expected keyword \"END\" but instead found " + token);
        token = tokens.dequeue();
        Reporter.assertElseFatalError(token.equals("WHILE"),
                "Expected \"WHILE\", but instead found " + token);

    }

    /**
     * Parses a CALL statement from {@code tokens} into {@code s}.
     *
     * @param tokens
     *            the input tokens
     * @param s
     *            the parsed statement
     * @replaces s
     * @updates tokens
     * @requires [identifier string is a proper prefix of tokens]
     * @ensures <pre>
     * s =
     *   [CALL Statement corresponding to identifier string at start of #tokens]  and
     *  #tokens = [identifier string at start of #tokens] * tokens
     * </pre>
     */
    private static void parseCall(Queue<String> tokens, Statement s) {
        assert tokens != null : "Violation of: tokens is not null";
        assert s != null : "Violation of: s is not null";
        assert tokens.length() > 0
                && Tokenizer.isIdentifier(tokens.front()) : tokens.front()
                        + " Violation of: identifier string is proper prefix of tokens";
        System.out.println("Call called");

        s.assembleCall(tokens.dequeue());

        //s.parseBlock(tokens);
    }

    /*
     * Constructors -----------------------------------------------------------
     */

    /**
     * No-argument constructor.
     */
    public Statement1Parse1() {
        super();
    }

    /*
     * Public methods ---------------------------------------------------------
     */

    @Override
    public void parse(Queue<String> tokens) {
        assert tokens != null : "Violation of: tokens is not null";
        assert tokens.length() > 0 : ""
                + "Violation of: Tokenizer.END_OF_INPUT is a suffix of tokens";
        this.parseBlock(tokens);
    }

    @Override
    public void parseBlock(Queue<String> tokens) {
        assert tokens != null : "Violation of: tokens is not null";
        assert tokens.length() > 0 : ""
                + "Violation of: Tokenizer.END_OF_INPUT is a suffix of tokens";
        Statement bdy = this.newInstance();
        System.out.println("Block called");

        if (!tokens.front().equals("### END OF INPUT ###")) {
            if (tokens.front().equals("WHILE")) {
                parseWhile(tokens, bdy);
                this.addToBlock(this.lengthOfBlock(), bdy);
                this.parseBlock(tokens);

            } else if (tokens.front().equals("IF")) {
                parseIf(tokens, bdy);
                this.addToBlock(this.lengthOfBlock(), bdy);
                this.parseBlock(tokens);
            } else if (Tokenizer.isIdentifier(tokens.front())) {
                parseCall(tokens, bdy);
                this.addToBlock(this.lengthOfBlock(), bdy);
                this.parseBlock(tokens);
            } else {

            }

        }
    }

    /*
     * Main test method -------------------------------------------------------
     */

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * Get input file name
         */
        //out.print("Enter valid BL statement(s) file name: ");
        String fileName = "C:\\CSE\\OsuCseWsTemplate\\workspace\\1BLParser\\test\\statement1.bl";
        //in.nextLine();
        /*
         * Parse input file
         */
        out.println("*** Parsing input file ***");
        Statement s = new Statement1Parse1();
        SimpleReader file = new SimpleReader1L(fileName);
        Queue<String> tokens = Tokenizer.tokens(file);
        file.close();
        out.println(tokens.toString());
        s.parse(tokens); // replace with parseBlock to test other method
        /*
         * Pretty print the statement(s)
         */
        out.println("*** Pretty print of parsed statement(s) ***");
        s.prettyPrint(out, 0);

        in.close();
        out.close();
    }

}
